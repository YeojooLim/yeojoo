package com.samsung.biz.board;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.samsung.biz.board.impl.BoardDAO;
import com.samsung.biz.board.vo.BoardVO;

public class AddBoardTest {

	public static void main(String[] args) {
		
		ApplicationContext factory = new ClassPathXmlApplicationContext("applicationContext.xml");

		BoardDAO dao = (BoardDAO)factory.getBean("boardDAO");
		BoardVO vo = (BoardVO)factory.getBean("boardVO");
		
	/*	BoardDAO dao = new BoardDAO();
		BoardVO vo = new BoardVO();*/
		
		vo.setTitle("TESTtitle");
		vo.setContent("TESTContent");
		vo.setNickname("TESTnickname");
		vo.setUserid("guest");
		dao.addBoard(vo);
		
	}

}
