package com.samsung.biz.board;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.samsung.biz.board.impl.BoardDAO;
import com.samsung.biz.board.vo.BoardVO;

public class DeleteBoardTest {

	public static void main(String[] args) {
/*		BoardVO vo = new BoardVO();
		BoardDAO dao = new BoardDAO();
		*/
		ApplicationContext factory = new ClassPathXmlApplicationContext("applicationContext.xml");
		BoardDAO dao = (BoardDAO)factory.getBean("boardDAO");
		BoardVO vo = (BoardVO)factory.getBean("boardVO");
		
		vo.setSeq(19);
		dao.deleteBoard(vo);
	}

}
