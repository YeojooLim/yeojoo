package com.samsung.biz.board.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.samsung.biz.board.BoardService;
import com.samsung.biz.board.vo.BoardVO;
import com.samsung.biz.common.JDBCUtils;

@Repository("fileDAO")
public class FileDAO  implements BoardService{

	private Connection conn = null;
	private PreparedStatement ps = null;
	private ResultSet rs = null;
	
	public ArrayList<BoardVO> getBoardList(BoardVO vo){
		System.out.println("FILE DAO");
		ArrayList<BoardVO> list = null;
		try{
			conn = JDBCUtils.getConnection();
			String sql = "";
			if(vo.getSearchCondition().equals("TITLE")){
				sql = "select * from board where title like '%' || ? || '%' order by seq desc";
			}else if(vo.getSearchCondition().equals("CONTENT")){
				sql = "select * from board where content like '%' || ? || '%' order by seq desc";
			}
			
			ps = conn.prepareStatement(sql);
			ps.setString(1, vo.getSearchKeyword());
			rs = ps.executeQuery();
			list = new ArrayList<BoardVO>();
			while(rs.next()){
				list.add(new BoardVO(rs.getInt("seq"), rs.getString("title"), rs.getString("nickname"), rs.getString("content"), rs.getDate("regdate"), rs.getInt("cnt"), rs.getString("userid")));
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn, ps, rs);
		}
		return list;
	}
	
	public BoardVO getBoard(BoardVO vo){
		
		BoardVO board = null;
		try{
			conn = JDBCUtils.getConnection();
			String sql = "select * from board where seq = ?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, vo.getSeq());
			rs = ps.executeQuery();
			
			if(rs.next()){
				board = new BoardVO(rs.getInt("seq"), rs.getString("title"), rs.getString("nickname"), rs.getString("content"), rs.getDate("regdate"), rs.getInt("cnt"), rs.getString("userid"));
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn, ps, rs);
		}
		return board;
	}
	
	public void addBoard(BoardVO vo){
		try{
			conn = JDBCUtils.getConnection();
			String sql = "insert into board (seq, title, nickname, content, userid) values( (select nvl(max(seq), 0)+1 from board), ?, ?, ?, ?)";
			ps = conn.prepareStatement(sql);
			ps.setString(1, vo.getTitle());
			ps.setString(2, vo.getNickname());
			ps.setString(3, vo.getContent());
			ps.setString(4, vo.getUserid());
			ps.executeUpdate();
			
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn, ps);
		}
	}

	public void updateBoard(BoardVO vo) {
		try{
			conn = JDBCUtils.getConnection();
			String sql = "update board set title = ?, content = ? where seq = ?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, vo.getTitle());
			ps.setString(2, vo.getContent());
			ps.setInt(3, vo.getSeq());
			ps.executeUpdate();
			
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn, ps);
		}
	}
	
	public void deleteBoard(BoardVO vo) {
		try{
			conn = JDBCUtils.getConnection();
			String sql = "delete from board where seq = ?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, vo.getSeq());
			ps.executeUpdate();
			
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn, ps);
		}
	}

}
