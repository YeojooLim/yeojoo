package com.samsung.view.board;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.samsung.biz.board.impl.BoardDAO;
import com.samsung.biz.board.vo.BoardVO;

public class GetBoardController implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		
		ModelAndView mv = new ModelAndView();

		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("id");
		
		if(id==null){
			mv.setViewName("login.jsp");
			return mv;
		}	
		BoardDAO dao = new BoardDAO();
		BoardVO vo = new BoardVO();
		
		int seq = Integer.parseInt(request.getParameter("seq"));
		vo.setSeq(seq);
		BoardVO board = dao.getBoard(vo);
		
		
		//request.setAttribute("board", board);
		//ModelAndView의 addObject 메소드가 지정한 이름으로 객체를 request에 담는다.
		mv.addObject("board", board);
		mv.setViewName("getBoard.jsp");
		return mv;
	}

}
