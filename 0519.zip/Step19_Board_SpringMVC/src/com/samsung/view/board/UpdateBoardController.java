package com.samsung.view.board;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.samsung.biz.board.impl.BoardDAO;
import com.samsung.biz.board.vo.BoardVO;

public class UpdateBoardController implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("id");
		ModelAndView mv = new ModelAndView();

		if(id==null){
			mv.setViewName("login.jsp");
			return mv;
		}	
		
		BoardVO vo = new BoardVO();
		vo.setTitle(request.getParameter("title"));
		vo.setContent(request.getParameter("content"));
		vo.setSeq(Integer.parseInt(request.getParameter("seq")));
		
		BoardDAO dao = new BoardDAO();
		dao.updateBoard(vo);
		
		mv.setViewName("getBoardList.do");
		return mv;
	}

}
