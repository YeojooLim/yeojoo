package com.samsung.view.board;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.samsung.biz.board.impl.BoardDAO;
import com.samsung.biz.board.vo.BoardVO;

public class AddBoardController implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();
		
		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("id");
	
		if(id==null){
			mv.setViewName("login.jsp");
			return mv;
		}	
		
		BoardDAO dao = new BoardDAO();
		BoardVO vo = new BoardVO();
		vo.setTitle(request.getParameter("title"));
		vo.setContent(request.getParameter("content"));
		vo.setNickname(request.getParameter("nickname"));
		vo.setUserid(id);
		dao.addBoard(vo);
		mv.setViewName("getBoardList.do");
		
		return mv;
	}
	
}
