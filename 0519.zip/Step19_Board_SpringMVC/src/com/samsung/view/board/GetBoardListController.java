package com.samsung.view.board;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.samsung.biz.board.impl.BoardDAO;
import com.samsung.biz.board.vo.BoardVO;

public class GetBoardListController implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		
		ModelAndView mv = new ModelAndView();

		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("id");
		
		if(id==null){
			mv.setViewName("login.jsp");
			return mv;
		}	
		
		String searchCondition = "TITLE";
		String searchKeyword = "";
		
		if(request.getParameter("searchCondition")!=null){
			searchCondition = request.getParameter("searchCondition");
		}
		
		if(request.getParameter("searchKeyword")!=null){
			searchKeyword = request.getParameter("searchKeyword");
		}
		
		BoardVO vo = new BoardVO();
		vo.setSearchCondition(searchCondition);
		vo.setSearchKeyword(searchKeyword);
		
		BoardDAO dao = new BoardDAO();
		ArrayList<BoardVO> boardList = dao.getBoardList(vo);
		mv.addObject("boardList", boardList);
		mv.setViewName("getBoardList.jsp");
		return mv;
	}

}
