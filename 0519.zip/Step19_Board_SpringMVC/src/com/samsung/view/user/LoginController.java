package com.samsung.view.user;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.samsung.biz.user.impl.UserDAO;
import com.samsung.biz.user.vo.UserVO;

public class LoginController implements Controller{
//spring controller도 handleRequest를 구현하도록 되어있고, 리턴타입이 ModelAndView 객체로 지정되어 있다.
//Model과 View가 함께 지정 가능한 객체
//Model은 request 객체에 값을 저장해 주는 기능
//View는 String 타입으로 이동할 페이지를 설정하는 기능
	
//return 되는 modelandview 객체는 web.xml에 등록된 spring의 dispatcherservlet 객체가 받아
//model 은 request에 view는 requestdispatcher에 담아
//처리하도록 한다.
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response){
		String id = request.getParameter("id");
		String password = request.getParameter("password");

		UserVO vo = new UserVO();
		vo.setId(id);
		vo.setPassword(password);
		UserDAO dao = new UserDAO();
		UserVO user = dao.login(vo);
		
		ModelAndView mv = new ModelAndView();
		if(user!=null){
			HttpSession session = request.getSession();
			session.setAttribute("name", user.getName());
			session.setAttribute("id", user.getId());
			mv.setViewName("getBoardList.do");
		}else{
			mv.setViewName("login.jsp");
		}
		return mv;
	}
}
