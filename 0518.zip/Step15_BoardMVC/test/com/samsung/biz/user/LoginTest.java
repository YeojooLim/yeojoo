package com.samsung.biz.user;

import com.samsung.biz.user.impl.UserDAO;
import com.samsung.biz.user.vo.UserVO;

public class LoginTest {

	public static void main(String[] args) {

		UserVO vo = new UserVO();
		vo.setId("guest");
		vo.setPassword("guest23");
		UserDAO dao = new UserDAO();
		UserVO user = dao.login(vo);
		if(user!=null){
			System.out.println(user);
		}else{
			System.out.println("사용자 존재하지 않음");
		}
	}

}
