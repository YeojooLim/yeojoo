package com.samsung.biz.board;

import com.samsung.biz.board.impl.BoardDAO;
import com.samsung.biz.board.vo.BoardVO;

public class AddBoardTest {

	public static void main(String[] args) {
		BoardDAO dao = new BoardDAO();
		BoardVO vo = new BoardVO();
		vo.setTitle("TESTtitle");
		vo.setContent("TESTContent");
		vo.setNickname("TESTnickname");
		vo.setUserid("guest");
		dao.addBoard(vo);
		
	}

}
