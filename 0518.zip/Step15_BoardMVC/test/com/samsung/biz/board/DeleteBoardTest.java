package com.samsung.biz.board;

import com.samsung.biz.board.impl.BoardDAO;
import com.samsung.biz.board.vo.BoardVO;

public class DeleteBoardTest {

	public static void main(String[] args) {
		BoardVO vo = new BoardVO();
		
		BoardDAO dao = new BoardDAO();
		vo.setSeq(21);
		dao.deleteBoard(vo);
	}

}
