package com.samsung.biz.user.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.samsung.biz.common.JDBCUtils;
import com.samsung.biz.user.vo.UserVO;

public class UserDAO {

	public UserVO login(UserVO vo){
		UserVO user = null;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = JDBCUtils.getConnection();
			String sql = "select * from users where id=? and password=?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, vo.getId());
			ps.setString(2, vo.getPassword());
			
			rs = ps.executeQuery();

			if(rs.next()){
				user = new UserVO(rs.getString("id"), rs.getString("password"), rs.getString("name"), rs.getString("role"));
			}

		}catch (SQLException e) {
			e.printStackTrace();
		}finally{
			JDBCUtils.close(conn, ps, rs);
		}
		
		return user;
	}
	
	public void logout(){
		
	}
}
